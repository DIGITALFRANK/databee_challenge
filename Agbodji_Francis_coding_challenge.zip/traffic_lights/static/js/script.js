console.log("JavaScript is working!");

const form = document.getElementById("myForm");

form.addEventListener("submit", (event) => {
    event.preventDefault();
    document.getElementById("myForm").style.display = "none";
    document.getElementById("instructions").textContent = "Your traffic light is working!";


    const formData = new FormData(form);
    const intervals = [];

    for (const key of formData.keys()) {
        console.log(key);
        if (formData.get(key).toString().length > 0) {
            intervals.push([key, parseInt(formData.get(key))*1000]);
        }
    }

    const listItems = document.querySelectorAll('.light');
    let currentIndex = 0;

    // reset on new user input submission
    listItems.forEach((item) => {
        item.style.opacity = .3;
    });
    listItems[0].style.opacity = 1;

    function highlightItem() {
    // Remove highlight from the previous item
    if (currentIndex > 0) {
        listItems[currentIndex - 1].style.opacity = .3;
    }
    if (currentIndex == 0) {
        listItems[listItems.length - 1].style.opacity = .3;
    }
    // Highlight the current item
    listItems[currentIndex].style.opacity = 1;
    // Move to the next item, looping back to the beginning if at the end
    currentIndex = (currentIndex + 1) % listItems.length;

    console.log("highlighting item", currentIndex);
    console.log(intervals);
    console.log(intervals[currentIndex]);
    //   setTimeout(highlightItem(), intervals[currentIndex][1]);
    if (currentIndex == 0) {
        setTimeout(highlightItem, intervals[listItems.length - 1][1]);
    } else {
    setTimeout(highlightItem, intervals[currentIndex-1][1]);
    }
    }


    highlightItem();

});


// timer logic
let seconds = 60; // Set initial time in seconds
let timerInterval = setInterval(updateTimer, 1000); // Update every second

function updateTimer() {
    seconds--;
    let minutes = Math.floor(seconds / 60);
    let remainingSeconds = seconds % 60;
    document.getElementById("timer").textContent = `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;

    if (seconds <= 0) {
        clearInterval(timerInterval); // Stop timer when it reaches 0
        alert("System is exiting! Please reenter for new simulation.");
        location.href = '/'; // Redirect to the home page
    }
}

// manual exit logic
document.getElementById("exit").addEventListener("click", function() {
    alert("System is exiting! Thank you for using the simulator."); 
});




