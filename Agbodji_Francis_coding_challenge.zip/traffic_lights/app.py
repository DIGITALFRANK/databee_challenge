import time
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/simulator', methods=['GET', 'POST'])
def simulator():
    lights = {}
    # this functionality can work with Jinja, but it's easier done in Javascript
    if request.method == 'POST':
        lights = {
            'red': request.form['red'],
            'yellow': request.form['yellow'],
            'green': request.form['green']
        }
        try:
            while True:
                for light, duration in lights:
                    print(f"The light is {light} for {duration} seconds.")
                    time.sleep(duration)  # Wait for the specified duration
                    print(f"{light} light is now off.\n")
        
        except KeyboardInterrupt:
            print("\nTraffic Light Simulator ended.")
        return render_template('simulator.html', lights=lights)
    return render_template('simulator.html', lights=lights)

if __name__ == '__main__':
    app.run(debug=True)