import time

# Function to simulate the traffic light
def traffic_light_simulator():
    print("Welcome to the Traffic Light Simulator!")
    
    # Get user input for the duration of each light
    red_duration = int(input("Enter the duration for the Red light in seconds: "))
    yellow_duration = int(input("Enter the duration for the Yellow light in seconds: "))
    green_duration = int(input("Enter the duration for the Green light in seconds: "))
    
    # List to hold the colors and their durations
    lights = [("Red", red_duration), ("Yellow", yellow_duration), ("Green", green_duration)]
    
    try:
        while True:
            for light, duration in lights:
                print(f"The light is {light} for {duration} seconds.")
                time.sleep(duration)  # Wait for the specified duration
                print(f"{light} light is now off.\n")
    
    except KeyboardInterrupt:
        print("\nTraffic Light Simulator ended.")
        
# Run the simulator
if __name__ == "__main__":
    traffic_light_simulator()
